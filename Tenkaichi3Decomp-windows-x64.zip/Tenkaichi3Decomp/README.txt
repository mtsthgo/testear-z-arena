Dragon Ball Z: Budokai Tenkaichi 3 - PC port (Windows, 64-bit)

1. Start  Tenkaichi3Decomp-setup.exe
2. Choose your own disc image of the USA release (SLUS-21678), an .iso file.
   The setup checks it and unpacks the game's data next to this file. About 4 GB are needed.
3. Press Play. Later, start  Tenkaichi3Decomp.exe  itself (or the setup again, and press Play).

In the game, F1 opens the settings: resolution, widescreen, controls and sound.
Saves are kept in saves/. A file placed in gamedata/mods/<same path as the original> replaces the original.
Texture packs (PCSX2 naming, .dds or .png) go into textures/, stages and music from outside the disc into
stages/ and songs/: see the note in each folder.

This package contains no game data. The game's data comes from your disc and stays on your computer.
